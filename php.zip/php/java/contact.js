var form = document.getElementById('f');

function myFunction() {
  if (form.checkValidity()) {
    alert("Gegevens verstuurd");
  }
}
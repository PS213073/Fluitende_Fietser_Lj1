fietsen.txt:
- kolom 1 : id
- kolom 2 : naam
- kolom 3 : elektrisch
- kolom 4 : prive zakelijk beide
- kolom 5 : dames heren kind
- kolom 6 : stads transport oma vouw hybride
- kolom 7 : merk
- kolom 8 : nieuw 2e hands
- kolom 9 : kleur(en)
- kolom 10 : prijs
- kolom 11 : opmerkingen


in fietsverhuur.txt:
- kolom 1 : naam fiets
- kolom 2 : prijs per tijdseenheid
- kolom 3 : aantal te verhuren fietsen